module.exports = {
    token: "토큰을 넣어주세요!",
    serverID: "본인이 사용할 서버 ID 를 넣어주세요!",
    categoryID: "문의 채널을 생성할 카테고리를 넣어주세요!",
    footer: "서버이름을 넣어주세요!",
    ticketCloseMessage: "> **관리자에 의해 문의가 종료되었습니다!**\n\n> **또다른 문의내용이 있다면 작성해주세요!**\n\n> **감사합니다 열심히 하겠습니다.**" // The message DMed to users after their ticket is closed
}